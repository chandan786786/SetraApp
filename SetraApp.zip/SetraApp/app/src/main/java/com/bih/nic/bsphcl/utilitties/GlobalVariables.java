package com.bih.nic.bsphcl.utilitties;


import com.bih.nic.bsphcl.model.UserInfo2;

/**
 * Created by NIC2 on 1/10/2018.
 */
public class GlobalVariables {
	public static UserInfo2 LoggedUser;
}

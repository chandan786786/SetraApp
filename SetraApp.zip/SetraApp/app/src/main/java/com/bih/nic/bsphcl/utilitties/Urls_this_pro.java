package com.bih.nic.bsphcl.utilitties;

/**
 * Created by NIC2 on 03-07-2018.
 */

public class Urls_this_pro {

    //live
   /* public static final String NSC_OUIRY_VERSION = "http://164.100.37.5/authstaff/nic/seitra/queryVersion";
    public static final String LOG_IN_URL = "http://164.100.37.5/authstaff/nic/seitra/login?reqStr=";
    public static final String OTP_IN_URL = "http://164.100.37.5/authstaff/nic/seitra/reqOTP?reqStr=";
    public static final String REGISTER_IN_URL = "http://164.100.37.5/authstaff/nic/seitra/register?reqStr=";
    public static final String LOGIN_OTP_IN_URL = "http://164.100.37.5/authstaff/nic/seitra/genpin?reqStr=";
    public static final String TRAN_OTP_IN_URL = "http://164.100.37.5/authstaff/nic/seitra/genTpin?reqStr=";*/


    //local
    /*public static final String NSC_OUIRY_VERSION = "http://192.168.1.95:8084/authstaff/nic/seitra/queryVersion";
    public static final String LOG_IN_URL = "http://192.168.1.95:8084/authstaff/nic/seitra/login?reqStr=";
    public static final String OTP_IN_URL = "http://192.168.1.95:8084/authstaff/nic/seitra/reqOTP?reqStr=";
    public static final String REGISTER_IN_URL = "http://192.168.1.95:8084/authstaff/nic/seitra/register?reqStr=";
    public static final String LOGIN_OTP_IN_URL = "http://192.168.1.95:8084/authstaff/nic/seitra/genpin?reqStr=";
    public static final String TRAN_OTP_IN_URL = "http://192.168.1.95:8084/authstaff/nic/seitra/genTpin?reqStr=";*/


    //live 2
    public static final String NSC_OUIRY_VERSION = "http://energybills.bsphcl.co.in/authstaff/nic/seitra/queryVersion";
    public static final String LOG_IN_URL = "http://energybills.bsphcl.co.in/authstaff/nic/seitra/login?reqStr=";
    public static final String OTP_IN_URL = "http://energybills.bsphcl.co.in/authstaff/nic/seitra/reqOTP?reqStr=";
    public static final String REGISTER_IN_URL = "http://energybills.bsphcl.co.in/authstaff/nic/seitra/register?reqStr=";
    public static final String LOGIN_OTP_IN_URL = "http://energybills.bsphcl.co.in/authstaff/nic/seitra/genpin?reqStr=";
    public static final String TRAN_OTP_IN_URL = "http://energybills.bsphcl.co.in/authstaff/nic/seitra/genTpin?reqStr=";
    public static final String New_IN_URL = "";
}